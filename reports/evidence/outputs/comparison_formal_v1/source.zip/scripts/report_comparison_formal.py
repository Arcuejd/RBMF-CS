"""Render the completed, validation-selected comparison from saved records only."""
import argparse
import csv
import json
from collections import Counter
from pathlib import Path


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def run(root, figures, tuning, output):
    cfg, manifest = load(root/'config.json'), load(root/'manifest.json')
    selection = load(root/'selection.json')
    verification = load(root/'verification.json')
    ledger = load(root/'ledger.json')
    rows = list(csv.DictReader((figures/'summary.csv').open(encoding='utf-8-sig')))
    pairs = load(figures/'paired_statistics.json')
    scores, planning = load(tuning/'scores.json'), load(tuning/'planning_scores.json')
    settings = cfg['comparison']
    budget = max(settings['budgets'])
    def fmt(x):
        return '不可用' if x is None or x == '' else f'{float(x):.6f}'
    def get(branch, method, scenario='clean'):
        return next(r for r in rows if r['branch'] == branch and r['method'] == method and r['scenario'] == scenario and int(r['requested_nodes']) == budget)
    lines = ['# 验证集选择后的 RBMF-CS / MC-EIR 探索性比较', '',
        f"运行状态：{manifest['status']}。完成预注册批量执行不等于获得独立测试证据。2014 年已用于诊断和开发，本轮仍为探索性评估；没有未见的独立配对测试年份。", '',
        '## 数据、规模与隔离', '',
        '2000–2012 训练、2013 全年验证、2014 四个已有月份探索性评估。2013 补充 LF/海冰通过独立输入审计；训练工件、HF 和网格保持不变。调参工作进程输入副本不含 2014 参考场和 LF。原始数据及历史结果均保留。', '',
        '本实验以 IAP 格点温度作为 HF 参考场、ORAS5 作为 LF 候选，从参考格点模拟传感器采样并加入预先生成的污染；不是独立 Argo/ITP 点观测的野外验证。HF/LF 是建模约定，尚未证明 IAP 在全部目标位置精度高于 ORAS5；产品内部同化相关性也不能由项目时间划分消除。误差与覆盖率均相对于 IAP 参考场解释。', '',
        f"种子 {settings['seeds']}；月份 {settings['dates']}；预算 {settings['budgets']}；场景 {settings['scenarios']}。共 {len(ledger)} 个案例。状态计数：{dict(Counter(e['status'] for e in ledger))}。进程异常记录数 {sum(e.get('method_failures', 0) for e in ledger)}；非收敛、提前停止另在逐预算结果中保留。", '',
        '同一案例全方法共享按节点预生成的扰动，观测器只公开已选节点。重构比较使用相同约束 Maximin 节点；部署比较固定 RBMF-CS。固定评价格点不采样，面积权重 cos(latitude)，NRMSE 分母为该域训练异常的加权 RMS。数据准备、参数空间、公式和来源见 comparison_protocol.md 及 2013 补充协议。', '',
        '高斯标准差 0.02℃；t(3) 按等方差缩放；离群、缺测、LF 偏移和训练污染独立。仅考察协议固定污染尺度，没有依据结果增加强度以制造优势。LF +0.2℃ 是固定方向的敏感性分析，可能抵消原有负偏差。训练污染改变 POD/covariance 输入，保持原气候态和尺度，不能推广为所有预处理均污染。部署的方差下降采用冻结超参数的高斯近似，没有对未来完整 VB 重拟合做精确积分。', '',
        '## 验证选择', '',
        '| 方法 | 搜索数 | 可用候选 | 选定参数 |', '|---|---:|---:|---|']
    for method in sorted({s['method'] for s in scores}):
        group = [s for s in scores if s['method'] == method]
        selected = {'rank': selection['comparison']['method_rank'][method],
                    'lambda': selection['comparison']['regularization'][method],
                    'inference': selection['comparison']['method_inference'][method]}
        lines.append(f"| {method} | {len(group)} | {sum(s['score'] is not None for s in group)} | `{json.dumps(selected)}` |")
    lines += [f"| MC-EIR | {len(planning)} | {sum(s['score'] is not None for s in planning)} | `{json.dumps(selection['planning'])}` |", '',
        '全部候选记录均保留。验证目标为 12 月 × 3 配对种子 × 3 节点预算的平均面积 RMSE，任何未收敛/失败使候选不可选。消融继承完整方法的验证参数，不利用探索性评估调参。', '',
        f'## {budget} 节点比较', '',
        '下表误差仅汇总收敛且实际达到该预算的案例；成功数/计划数必须一起阅读。未达到预算的结果没有并入同预算误差。CSV 另含 MAE、NRMSE、实际节点、能耗、成本、可行率和分项运行时间。']
    for branch in ['reconstruction', 'deployment']:
        lines += ['', '### '+branch, '', '| 方法 | clean RMSE ℃ | Gaussian RMSE ℃ | clean 收敛同预算/计划 | clean 可行率 |', '|---|---:|---:|---:|---:|']
        for method in settings[branch]:
            a, b = get(branch, method), get(branch, method, 'gaussian')
            lines.append(f"| {method} | {fmt(a['rmse_c'])} | {fmt(b['rmse_c'])} | {a['converged_same_count_cases']}/{a['planned_cases']} | {fmt(a['feasible_rate_of_planned'])} |")
    lines += ['', '## 配对差值与适用边界', '',
        '差值为表中方法减完整参考方法（重构 RBMF、部署 MC-EIR），负数有利于表中方法。以下是 clean 最大预算；全部场景和预算见 paired_statistics.csv/json。只使用四个月均有可用配对的种子，同时报告分母。', '',
        '| 分支/方法 | 配对平均差 ℃ | 固定环境种子条件95%区间 | 时间/空间分块95%敏感性区间 | 配对种子/计划 |', '|---|---:|---|---|---:|']
    for p in pairs:
        if p['scenario'] == 'clean' and p['budget'] == budget:
            lines.append(f"| {p['branch']}/{p['method']} | {fmt(p['paired_mean_difference_c'])} | {p.get('seed_conditional_ci95_c')} | {p.get('time_space_block_sensitivity95_c')} | {len(p['paired_seeds'])}/{p['planned_seeds']} |")
    for branch, reference in [('reconstruction', 'rbmf'), ('deployment', 'mc_eir')]:
        valid = [p for p in pairs if p['branch'] == branch and p['scenario'] == 'clean' and p['budget'] == budget and p['paired_mean_difference_c'] is not None and not p['method'].startswith('no_')]
        better = [p['method'] for p in valid if p['paired_mean_difference_c'] < 0]
        lines += ['', f"在 clean 最大预算的可用配对结果中，平均误差低于 {reference} 的基线为：{', '.join(better) if better else '未观察到'}。这是当前固定环境下的描述，不是跨年份统计优越性声明。"]
    lines += ['', '种子不是独立环境样本。空间按2°×5°分块、时间按相邻两个观测月份循环分块；只有四个相关月份，区间仅作探索性敏感性分析。独立环境 p 值和 Holm 校正 p 值留空；没有制造多方法显著性。', '',
        '## 失败、约束代价与消融', '',
        '| 分支/方法/场景 | 预算 | 收敛同预算/计划 |', '|---|---:|---:|']
    incomplete = [r for r in rows if int(r['converged_same_count_cases']) < int(r['planned_cases'])]
    for r in incomplete:
        lines.append(f"| {r['branch']}/{r['method']}/{r['scenario']} | {r['requested_nodes']} | {r['converged_same_count_cases']}/{r['planned_cases']} |")
    if not incomplete:
        lines.append('| 无 | — | 全部达到预算并收敛 |')
    lines += ['', '原始状态、错误及未收敛诊断见 metrics.csv、failures.json、运行 ledger 和逐案例记录。POD-QR 残差为零时停止，不将数值舍入误差当作有效 pivot；超过所选 POD 秩的预算可能不可用。熵权 QR 使用论文负指示器信息权重乘残差范数，属于工程约束适配，未声称原论文严格复现。', '',
        '| 约束代价方法 | clean RMSE ℃ | 可行率（按原约束审计） | 成本 | 能耗 J |', '|---|---:|---:|---:|---:|']
    for method in ['pod_qr', 'unconstrained_pod_qr', 'mc_eir', 'unconstrained_mc_eir']:
        r = get('deployment', method)
        lines.append(f"| {method} | {fmt(r['rmse_c'])} | {fmt(r['feasible_rate_of_planned'])} | {fmt(r['cost'])} | {fmt(r['mission_energy_j'])} |")
    lines += ['', '无约束版本单列，不纳入主比较。去多保真删除兼容因子及相应更新/ELBO 项；去鲁棒似然固定局部精度为1并删除局部 Gamma 项。四个部署消融删除对应评分项，仍保留全部硬约束。消融效果不预设为正。工程成本/能耗参数是场景假设，不是实测设备验证。', '',
        '## 不确定性', '', '| 方法 | Gaussian 潜在场覆盖 | 潜在场宽度 ℃ | 未来观测覆盖 | 未来观测宽度 ℃ |', '|---|---:|---:|---:|---:|']
    for method in ['rbmf', 'gaussian_sbl_vb', 'no_robust', 'no_mf']:
        r = get('reconstruction', method, 'gaussian')
        lines.append(f"| {method} | {fmt(r['latent_coverage95'])} | {fmt(r['latent_width95_c'])} | {fmt(r['future_coverage95'])} | {fmt(r['future_width95_c'])} |")
    if selection['planning']['eta'] == 0:
        lines += ['', '验证选择的冗余惩罚系数 eta=0，完整方法的选点评分已不含冗余惩罚。因此去冗余消融与完整方法评分相同，本轮不能用这一相同结果判断非零冗余惩罚在其他环境中的贡献。']
    lines += ['', '潜在场区间来自系数后验；未来观测区间另积分噪声精度和新局部精度，用独立预生成未来观测评价。覆盖率和宽度必须一起解释。遗漏基底学习、截断、模型差异和 mean-field 交叉协方差，不能凭较宽的未来观测区间声称潜在场校准良好。没有使用探索性真值校准区间。', '',
        '## 验收、运行时间与复现', '',
        f"保存结果核验：passed={verification['passed']}，{verification['checks']} 项检查，{verification['recomputed_predictions']} 份预测重新计算指标。固定种子重跑证据见选定参数 pilot 的 repeat_verification.json；单元参考测试见测试日志。正式并发数 {manifest['workers']}，批次墙钟 {manifest['wall_seconds']:.2f} 秒，案例耗时累计 {manifest.get('sum_case_seconds', manifest['wall_seconds']):.2f} 秒。预处理、选点、重构时间分开记录；并发和审计 I/O 会影响总墙钟，不据此声称算法固有速度优势。", '',
        f"运行目录：`{root.as_posix()}`；验证选择：`{tuning.as_posix()}`；图表：`{figures.as_posix()}`。源码、输入副本、版本、种子、逐步预测/后验/迭代/约束均归档，部署大日志为 `.json.gz`。", '',
        '重绘不拟合模型，不改数据、不平滑、不强制单调。空间图按最早月份、最小种子、clean、最大计划预算固定选择，使用共同色标。', '', '```powershell',
        '.venv\\Scripts\\python -m unittest discover -s tests -v',
        '.venv\\Scripts\\python scripts/tune_comparison_batch.py --config configs/comparison_2013_v1.json --output outputs/validation_new --workers 6',
        '.venv\\Scripts\\python scripts/run_comparison.py --mode pilot --config configs/comparison_2013_v1.json --selection outputs/validation_new/selection.json --full-pilot-budgets --workers 6 --output outputs/selected_pilot_new',
        '.venv\\Scripts\\python scripts/verify_comparison.py outputs/selected_pilot_new',
        '.venv\\Scripts\\python scripts/run_comparison.py --mode formal --config configs/comparison_2013_v1.json --selection outputs/validation_new/selection.json --pilot-verification outputs/selected_pilot_new/verification.json --workers 6 --output outputs/formal_new',
        f'.venv\\Scripts\\python scripts/verify_comparison.py {root.as_posix()}',
        f'.venv\\Scripts\\python scripts/plot_comparison.py {root.as_posix()} --output outputs/figures_new',
        f'.venv\\Scripts\\python scripts/report_comparison_formal.py {root.as_posix()} --figures outputs/figures_new --tuning {tuning.as_posix()} --output docs/report_new.md', '```', '',
        '输出目录必须不存在。复现固定数值允许绝对误差1e-12，运行时间不要求一致；归档 runtime 提供当次原始源码。历史诊断与未调参 pilot 见 comparison_report.md，不能与本次已验证参数结果混为一组。']
    output.write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print(output)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('root', type=Path)
    p.add_argument('--figures', required=True, type=Path)
    p.add_argument('--tuning', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    a = p.parse_args()
    run(a.root, a.figures, a.tuning, a.output)
